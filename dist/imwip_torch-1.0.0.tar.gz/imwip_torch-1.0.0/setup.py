from setuptools import setup, find_packages


setup(
    name="imwip_torch",
    version="1.0",
    packages=find_packages(),
)